clc;
clear;
load('VAR_data');
X = [rgov_pot, rgdp_pot];
results_1 = zeros(8,9,2);
results_2 = zeros(8,9,2);
endtime = 36;
X_1 = X(1:end-endtime,:);
for h = 1:4
    [results_1(2*h-1,:,1),results_2(2*h-1,:,1),results_1(2*h,2:9,1),results_2(2*h,2:9,1)] = emrecursivenp(X_1,116-h+1,h);
end
for h = 1:4
    [results_1(2*h-1,:,2),results_2(2*h-1,:,2),results_1(2*h,2:9,2),results_2(2*h,2:9,2)] = emrecursivenp(X,212-h+1,h);
end
writematrix(results_1, 'output1.xlsx', 'Sheet', 'results_1');
writematrix(results_2, 'output1.xlsx', 'Sheet', 'results_2');
