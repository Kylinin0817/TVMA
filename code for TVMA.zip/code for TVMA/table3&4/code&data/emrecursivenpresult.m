clc;
clear;
load('VAR_data');
X = [rgov_pot, rgdp_pot];
results_1 = zeros(8,9,5);
results_2 = zeros(8,9,5);
for i = 1:5
    for h = 1:4
        [results_1(2*h-1,:,i),results_2(2*h-1,:,i),results_1(2*h,2:9,i),results_2(2*h,2:9,i)] = emrecursivenp(X,104+20*i-h+1,h);
    end
end
writematrix(results_1, 'output1.xlsx', 'Sheet', 'results_1');
writematrix(results_2, 'output1.xlsx', 'Sheet', 'results_2');
