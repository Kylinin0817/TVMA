function [RMSE_all_1,RMSE_all_2,dm_pvalue_1,dm_pvalue_2] = emrecursivenp(X,T_est,h)
    [T,d] = size(X); % d denotes the dimension of x_t
    Pmax = 5;
    
    Y_fit = zeros(T_est-Pmax,d,T-T_est-h+1,Pmax);
    eta_hat = zeros(T_est-Pmax,d,T-T_est-h+1,Pmax);
    Y_pre = zeros(T-T_est-h+1,d,Pmax);
    Omega_hat = zeros(d,d,(T_est-Pmax),(T-T_est-h+1),Pmax);

    for p = 1:Pmax
        X_lag = zeros((T-p-h+1),d*p+1);
        for t = 1:(T-p-h+1)
            temp = 1;
            for r = 1:p
                temp = [temp,X(p+t-r,:)];
            end
            X_lag(t,:) = temp;
        end
        X_p = X(p+1:T-h+1,:); % regresan
        h_opt = 2.34*sqrt(1/12)*(T_est-p)^(-0.2);
        Y_fit_p = zeros(T_est-p,d,T-T_est-h+1);
        eta_hat_p = zeros(T_est-p,d,T-T_est-h+1);
        Y_pre_p = zeros(T-T_est-h+1,d);
        for s = 1:(T-T_est-h+1)
            A_hat_p_s = zeros(d,d*p+1,T_est-p);
            X_lag_p_s = X_lag(s:(T_est-p+s-1),:);
            X_p_s = X_p(s:(T_est-p+s-1),:);
            for t = 1:(T_est-p)
                tau_t = t/(T_est-p);
                K = K_weight(T_est-p,tau_t,h_opt);   % kernel weighting matrix
                Z = Z_data(X_lag_p_s,tau_t,h_opt);
                A_hat_p_s(:,:,t) = ([eye(d*p+1) zeros(d*p+1)]*((Z'*K*Z)\(Z'*K*X_p_s)))';
                Y_fit_p(t,:,s) = X_lag_p_s(t,:)*A_hat_p_s(:,:,t)';
                eta_hat_p(t,:,s) = X_p_s(t,:)-X_lag_p_s(t,:)*A_hat_p_s(:,:,t)'; % estimates of reduced form residuals
            end
            y_pred = zeros(1, h*d);

            for i = 1:h
                if i <= p
                    y_lagged = [X_lag(T_est-p+s,1), y_pred(:,(end-d*(i-1)+1):end), X_lag(T_est-p+s,2:(1+2*p-2*i+2))];
                else
                    y_lagged = [1, y_pred(:, (end-2*i+3):(end-2*(i-p-1)))];
                end
                y_pred(:,(end-2*i+1):(end-2*i+2)) = y_lagged * A_hat_p_s(:,:,T_est-p)';
            end
            Y_pre_p(s,:) = y_pred(:,1:2);
            for t = (1+Pmax-p):(T_est-p)
                tau_t = t/(T_est-p);
                K_Ome = K_weight(T_est-p,tau_t,h_opt);   % kernel weighting matrix
                Omega_hat(:,:,(t-Pmax+p),s,p) = eta_hat_p(:,:,s)'*K_Ome*eta_hat_p(:,:,s)/(sum(diag(K_Ome))); 
            end
        end
        Y_fit(:,:,:,p) = Y_fit_p((1+Pmax-p):end,:,:);
        eta_hat(:,:,:,p) = eta_hat_p((1+Pmax-p):end,:,:);
        Y_pre(:,:,p) = Y_pre_p;
    end
    
    PVEC= 1:Pmax;
    h_opt_ma = 2.34*sqrt(1/12)*(T_est-Pmax)^(-0.2);
    Y_ma = zeros(T-T_est-h+1,2);
    Y_AIC = zeros(T-T_est-h+1,2);
    Y_BIC = zeros(T-T_est-h+1,2);
    Y_HQ = zeros(T-T_est-h+1,2);
    Y_sAIC = zeros(T-T_est-h+1,2);
    Y_sBIC = zeros(T-T_est-h+1,2);
    Y_sHQ = zeros(T-T_est-h+1,2);
    Y_SA = zeros(T-T_est-h+1,2);
    AIC=zeros(T-T_est-h+1,Pmax);
    BIC=zeros(T-T_est-h+1,Pmax);
    HQ=zeros(T-T_est-h+1,Pmax);
    ww_mat = zeros(T-T_est-h+1,Pmax);
    ww_sAIC = zeros(T-T_est-h+1,Pmax);
    ww_sBIC = zeros(T-T_est-h+1,Pmax);
    ww_sHQ = zeros(T-T_est-h+1,Pmax);
    for i = 1:(T-T_est-h+1)
        QQ = zeros(Pmax,Pmax);
        K_ma = K_weight(T_est-Pmax,1,h_opt_ma);
        for j = 1:T_est-Pmax
            QQ = QQ + K_ma(j,j)*squeeze(eta_hat(j,:,i,:))'/squeeze(Omega_hat(:,:,T_est-Pmax,i,Pmax))*squeeze(eta_hat(j,:,i,:));
        end
        QQ = QQ + QQ';
        B = 2 * log((T_est-Pmax)*h_opt_ma) * d^2 * PVEC';
        ww=quadprog(QQ,B,zeros(1,Pmax),0,ones(1,Pmax),1,zeros(Pmax,1),ones(Pmax,1)); 
        ww=ww.*(ww>0); 
        ww=ww/sum(ww);
        ww_mat(i,:) = ww';
        Y_ma(i,:) = (squeeze(Y_pre(i,:,:)) * ww)';
        for p = 1:Pmax
            Omega_residual = eta_hat(:,:,i,p)' * eta_hat(:,:,i,p) / (T_est-Pmax);
            AIC(i,p) = log(det(squeeze(Omega_residual))) + 2*p*d^2/(T_est-Pmax);
            BIC(i,p) = log(det(squeeze(Omega_residual))) + log(T_est-Pmax)  * p * d^2 /(T_est-Pmax);
            HQ(i,p) = log(det(squeeze(Omega_residual))) + 2*log(log(T_est-Pmax))*p*d^2/(T_est-Pmax);
        end
        ww_sAIC(i,:) = exp(-AIC(i,:)/2);
        ww_sBIC(i,:) = exp(-BIC(i,:)/2);
        ww_sHQ(i,:) = exp(-HQ(i,:)/2);
        ww_sAIC(i,:) = ww_sAIC(i,:)/sum(ww_sAIC(i,:));
        ww_sBIC(i,:) = ww_sBIC(i,:)/sum(ww_sBIC(i,:));
        ww_sHQ(i,:) = ww_sHQ(i,:)/sum(ww_sHQ(i,:));
        Y_sAIC(i,:) = ww_sAIC(i,:) * squeeze(Y_pre(i,:,:))';
        Y_sBIC(i,:) = ww_sBIC(i,:) * squeeze(Y_pre(i,:,:))';
        Y_sHQ(i,:) = ww_sHQ(i,:) * squeeze(Y_pre(i,:,:))';
        Y_SA(i,:) = ones(1,Pmax) / Pmax * squeeze(Y_pre(i,:,:))';
        [~,loctempAIC] = min(AIC(i,:));
        Y_AIC(i,:) = squeeze(Y_pre(i,:,loctempAIC))';
        [~,loctempBIC] = min(BIC(i,:));
        Y_BIC(i,:) = squeeze(Y_pre(i,:,loctempBIC))';
        [~,loctempHQ] = min(HQ(i,:));
        Y_HQ(i,:) = squeeze(Y_pre(i,:,loctempHQ))';
    end
    Y_true = X(T_est+h:end,:);
    RMSE = zeros(Pmax,2);
    for p = 1:Pmax
        residual_1 = Y_true(:,1)- squeeze(Y_pre(:,1,p));
        residual_2 = Y_true(:,2)- squeeze(Y_pre(:,2,p));
        RMSE_1 = sqrt(residual_1'*residual_1/(T-T_est-h+1));
        RMSE_2 = sqrt(residual_2'*residual_2/(T-T_est-h+1));
        RMSE(p,:) = [RMSE_1 RMSE_2];
    end
    residual_1_nic = Y_true(:,1)- squeeze(Y_pre(:,1,2));
    residual_2_nic = Y_true(:,2)- squeeze(Y_pre(:,2,2));
    residual_ma = Y_true - Y_ma;
    residual_NIC = [residual_1_nic, residual_2_nic];
    residual_AIC = Y_true - Y_AIC;
    residual_BIC = Y_true - Y_BIC;
    residual_HQ = Y_true - Y_HQ;
    residual_sAIC = Y_true - Y_sAIC;
    residual_sBIC = Y_true - Y_sBIC;
    residual_sHQ = Y_true - Y_sHQ;
    residual_SA = Y_true - Y_SA;
    dm_sta_NIC_1 = dmtest(residual_ma(:,1), residual_NIC(:,1), h);
    dm_pvalue_NIC_1 = 2 * (1 - normcdf(abs(dm_sta_NIC_1)));
    dm_sta_NIC_2 = dmtest(residual_ma(:,2), residual_NIC(:,2), h);
    dm_pvalue_NIC_2 = 2 * (1 - normcdf(abs(dm_sta_NIC_2)));
    dm_sta_AIC_1 = dmtest(residual_ma(:,1), residual_AIC(:,1), h);
    dm_pvalue_AIC_1 = 2 * (1 - normcdf(abs(dm_sta_AIC_1)));
    dm_sta_AIC_2 = dmtest(residual_ma(:,2), residual_AIC(:,2), h);
    dm_pvalue_AIC_2 = 2 * (1 - normcdf(abs(dm_sta_AIC_2)));
    dm_sta_BIC_1 = dmtest(residual_ma(:,1), residual_BIC(:,1), h);
    dm_pvalue_BIC_1 = 2 * (1 - normcdf(abs(dm_sta_BIC_1)));
    dm_sta_BIC_2 = dmtest(residual_ma(:,2), residual_BIC(:,2), h);
    dm_pvalue_BIC_2 = 2 * (1 - normcdf(abs(dm_sta_BIC_2)));
    dm_sta_HQ_1 = dmtest(residual_ma(:,1), residual_HQ(:,1), h);
    dm_pvalue_HQ_1 = 2 * (1 - normcdf(abs(dm_sta_HQ_1)));
    dm_sta_HQ_2 = dmtest(residual_ma(:,2), residual_HQ(:,2), h);
    dm_pvalue_HQ_2 = 2 * (1 - normcdf(abs(dm_sta_HQ_2)));
    dm_sta_sAIC_1 = dmtest(residual_ma(:,1), residual_sAIC(:,1), h);
    dm_pvalue_sAIC_1 = 2 * (1 - normcdf(abs(dm_sta_sAIC_1)));
    dm_sta_sAIC_2 = dmtest(residual_ma(:,2), residual_sAIC(:,2), h);
    dm_pvalue_sAIC_2 = 2 * (1 - normcdf(abs(dm_sta_sAIC_2)));
    dm_sta_sBIC_1 = dmtest(residual_ma(:,1), residual_sBIC(:,1), h);
    dm_pvalue_sBIC_1 = 2 * (1 - normcdf(abs(dm_sta_sBIC_1)));
    dm_sta_sBIC_2 = dmtest(residual_ma(:,2), residual_sBIC(:,2), h);
    dm_pvalue_sBIC_2 = 2 * (1 - normcdf(abs(dm_sta_sBIC_2)));
    dm_sta_sHQ_1 = dmtest(residual_ma(:,1), residual_sHQ(:,1), h);
    dm_pvalue_sHQ_1 = 2 * (1 - normcdf(abs(dm_sta_sHQ_1)));
    dm_sta_sHQ_2 = dmtest(residual_ma(:,2), residual_sHQ(:,2), h);
    dm_pvalue_sHQ_2 = 2 * (1 - normcdf(abs(dm_sta_sHQ_2)));
    dm_sta_SA_1 = dmtest(residual_ma(:,1), residual_SA(:,1), h);
    dm_pvalue_SA_1 = 2 * (1 - normcdf(abs(dm_sta_SA_1)));
    dm_sta_SA_2 = dmtest(residual_ma(:,2), residual_SA(:,2), h);
    dm_pvalue_SA_2 = 2 * (1 - normcdf(abs(dm_sta_SA_2)));
    RMSE_ma_1 = sqrt(residual_ma(:,1)'*residual_ma(:,1)/(T-T_est-h+1));
    RMSE_ma_2 = sqrt(residual_ma(:,2)'*residual_ma(:,2)/(T-T_est-h+1));
    RMSE_AIC_1 = sqrt(residual_AIC(:,1)'*residual_AIC(:,1)/(T-T_est-h+1));
    RMSE_AIC_2 = sqrt(residual_AIC(:,2)'*residual_AIC(:,2)/(T-T_est-h+1));
    RMSE_BIC_1 = sqrt(residual_BIC(:,1)'*residual_BIC(:,1)/(T-T_est-h+1));
    RMSE_BIC_2 = sqrt(residual_BIC(:,2)'*residual_BIC(:,2)/(T-T_est-h+1));
    RMSE_HQ_1 = sqrt(residual_HQ(:,1)'*residual_HQ(:,1)/(T-T_est-h+1));
    RMSE_HQ_2 = sqrt(residual_HQ(:,2)'*residual_HQ(:,2)/(T-T_est-h+1));
    RMSE_sAIC_1 = sqrt(residual_sAIC(:,1)'*residual_sAIC(:,1)/(T-T_est-h+1));
    RMSE_sAIC_2 = sqrt(residual_sAIC(:,2)'*residual_sAIC(:,2)/(T-T_est-h+1));
    RMSE_sBIC_1 = sqrt(residual_sBIC(:,1)'*residual_sBIC(:,1)/(T-T_est-h+1));
    RMSE_sBIC_2 = sqrt(residual_sBIC(:,2)'*residual_sBIC(:,2)/(T-T_est-h+1));
    RMSE_sHQ_1 = sqrt(residual_sHQ(:,1)'*residual_sHQ(:,1)/(T-T_est-h+1));
    RMSE_sHQ_2 = sqrt(residual_sHQ(:,2)'*residual_sHQ(:,2)/(T-T_est-h+1));
    RMSE_SA_1 = sqrt(residual_SA(:,1)'*residual_SA(:,1)/(T-T_est-h+1));
    RMSE_SA_2 = sqrt(residual_SA(:,2)'*residual_SA(:,2)/(T-T_est-h+1));
    RMSE_all_1=[RMSE_ma_1,RMSE(2,1),RMSE_AIC_1,RMSE_BIC_1,RMSE_HQ_1,RMSE_sAIC_1,RMSE_sBIC_1,RMSE_sHQ_1,RMSE_SA_1];
    RMSE_all_2=[RMSE_ma_2,RMSE(2,2),RMSE_AIC_2,RMSE_BIC_2,RMSE_HQ_2,RMSE_sAIC_2,RMSE_sBIC_2,RMSE_sHQ_2,RMSE_SA_2];
    dm_pvalue_1=[dm_pvalue_NIC_1,dm_pvalue_AIC_1,dm_pvalue_BIC_1,dm_pvalue_HQ_1,dm_pvalue_sAIC_1,dm_pvalue_sBIC_1,dm_pvalue_sHQ_1,dm_pvalue_SA_1];
    dm_pvalue_2=[dm_pvalue_NIC_2,dm_pvalue_AIC_2,dm_pvalue_BIC_2,dm_pvalue_HQ_2,dm_pvalue_sAIC_2,dm_pvalue_sBIC_2,dm_pvalue_sHQ_2,dm_pvalue_SA_2];
end