clc;
clear;

FF = readtable('FF.csv');
GDP = readtable('GDPC1.xls');
GDPD = readtable('GDPDEF.xls');

FF_monthly_values = FF{:, 2};
GDP_quarterly_values = GDP{:, 2};
GDPD_quarterly_values = GDPD{:, 2};

num_months = length(FF_monthly_values);
num_quarters = floor(num_months / 3);

FF_quarterly_values = zeros(num_quarters, 1);

for i = 1:num_quarters
    FF_quarterly_values(i) = mean(FF_monthly_values((i-1)*3 + 1:i*3));
end

dlogGDP = diff(log(GDP_quarterly_values));
dlogGDPD = diff(log(GDPD_quarterly_values));
dFF = diff(FF_quarterly_values);

X = [dlogGDP, dlogGDPD, dFF];
begintime = 18;
endtime = 62;
X_1 = X(1+begintime:end-endtime,:);

results_1 = zeros(8,9,1);
results_2 = zeros(8,9,1);
results_3 = zeros(8,9,1);
for h = 1:4
    [results_1(2*h-1,:,1),results_2(2*h-1,:,1),results_3(2*h-1,:,1),results_1(2*h,2:9,1),results_2(2*h,2:9,1),results_3(2*h,2:9,1)] = emrecursivenpnew(X_1,100,h);
end


writematrix(results_1, 'output4.xlsx', 'Sheet', 'results_1');
writematrix(results_2, 'output4.xlsx', 'Sheet', 'results_2');
writematrix(results_3, 'output4.xlsx', 'Sheet', 'results_3');